﻿namespace GlobalShopping.Data
{
    public enum SupportedRegion
    {
        USA = 1, Europe, Asia
    }
}
