﻿namespace GlobalShopping.Models
{
    public class Region
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
