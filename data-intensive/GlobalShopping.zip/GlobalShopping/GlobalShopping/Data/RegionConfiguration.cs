﻿namespace GlobalShopping.Data
{
    public static class RegionConfiguration
    {
        public static SupportedRegion DefaultRegionID { get; set; } = SupportedRegion.USA;
    }
}
